vlr_tb = int(input("Digite o valor para o qual a tabuada será gerada: "))
i = 1  

while i <= 10:  
    result = vlr_tb * i
    print(f"{vlr_tb} X {i} = {result}")
    i += 1
