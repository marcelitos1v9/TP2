vetor_cores = []

for i in range(5):
    cor = input(f"Digite a cor {i+1}º: ")
    vetor_cores.append(cor)

print(vetor_cores)
